﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MuseumTool.JSON
{
    internal class Colleccions
    {
        public const string colleccionsDir = @"..\..\resources\colleccions.json";
        public string nombre { get; set; }
    }
}
