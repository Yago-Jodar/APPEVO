﻿namespace MuseumTool
{
    partial class gestorPreguntes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPregunta = new System.Windows.Forms.Label();
            this.textBoxPregunta = new System.Windows.Forms.TextBox();
            this.textBoxRespostaA = new System.Windows.Forms.TextBox();
            this.labelRespostaA = new System.Windows.Forms.Label();
            this.textBoxRespostaB = new System.Windows.Forms.TextBox();
            this.labelRespostaB = new System.Windows.Forms.Label();
            this.textBoxRespostaC = new System.Windows.Forms.TextBox();
            this.labelRespostaC = new System.Windows.Forms.Label();
            this.radioButtonA = new System.Windows.Forms.RadioButton();
            this.radioButtonB = new System.Windows.Forms.RadioButton();
            this.radioButtonC = new System.Windows.Forms.RadioButton();
            this.groupBoxRespostaCorrecta = new System.Windows.Forms.GroupBox();
            this.buttonDesar = new System.Windows.Forms.Button();
            this.groupBoxRespostaCorrecta.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelPregunta
            // 
            this.labelPregunta.AutoSize = true;
            this.labelPregunta.Location = new System.Drawing.Point(12, 9);
            this.labelPregunta.Name = "labelPregunta";
            this.labelPregunta.Size = new System.Drawing.Size(50, 13);
            this.labelPregunta.TabIndex = 0;
            this.labelPregunta.Text = "Pregunta";
            // 
            // textBoxPregunta
            // 
            this.textBoxPregunta.Location = new System.Drawing.Point(15, 25);
            this.textBoxPregunta.Multiline = true;
            this.textBoxPregunta.Name = "textBoxPregunta";
            this.textBoxPregunta.Size = new System.Drawing.Size(286, 47);
            this.textBoxPregunta.TabIndex = 1;
            // 
            // textBoxRespostaA
            // 
            this.textBoxRespostaA.Location = new System.Drawing.Point(15, 108);
            this.textBoxRespostaA.Name = "textBoxRespostaA";
            this.textBoxRespostaA.Size = new System.Drawing.Size(286, 20);
            this.textBoxRespostaA.TabIndex = 2;
            // 
            // labelRespostaA
            // 
            this.labelRespostaA.AutoSize = true;
            this.labelRespostaA.Location = new System.Drawing.Point(12, 92);
            this.labelRespostaA.Name = "labelRespostaA";
            this.labelRespostaA.Size = new System.Drawing.Size(65, 13);
            this.labelRespostaA.TabIndex = 0;
            this.labelRespostaA.Text = "Resposta A)";
            // 
            // textBoxRespostaB
            // 
            this.textBoxRespostaB.Location = new System.Drawing.Point(15, 147);
            this.textBoxRespostaB.Name = "textBoxRespostaB";
            this.textBoxRespostaB.Size = new System.Drawing.Size(286, 20);
            this.textBoxRespostaB.TabIndex = 3;
            // 
            // labelRespostaB
            // 
            this.labelRespostaB.AutoSize = true;
            this.labelRespostaB.Location = new System.Drawing.Point(12, 131);
            this.labelRespostaB.Name = "labelRespostaB";
            this.labelRespostaB.Size = new System.Drawing.Size(65, 13);
            this.labelRespostaB.TabIndex = 0;
            this.labelRespostaB.Text = "Resposta B)";
            // 
            // textBoxRespostaC
            // 
            this.textBoxRespostaC.Location = new System.Drawing.Point(15, 186);
            this.textBoxRespostaC.Name = "textBoxRespostaC";
            this.textBoxRespostaC.Size = new System.Drawing.Size(286, 20);
            this.textBoxRespostaC.TabIndex = 4;
            // 
            // labelRespostaC
            // 
            this.labelRespostaC.AutoSize = true;
            this.labelRespostaC.Location = new System.Drawing.Point(12, 170);
            this.labelRespostaC.Name = "labelRespostaC";
            this.labelRespostaC.Size = new System.Drawing.Size(65, 13);
            this.labelRespostaC.TabIndex = 0;
            this.labelRespostaC.Text = "Resposta C)";
            // 
            // radioButtonA
            // 
            this.radioButtonA.AutoSize = true;
            this.radioButtonA.Location = new System.Drawing.Point(30, 19);
            this.radioButtonA.Name = "radioButtonA";
            this.radioButtonA.Size = new System.Drawing.Size(32, 17);
            this.radioButtonA.TabIndex = 5;
            this.radioButtonA.TabStop = true;
            this.radioButtonA.Text = "A";
            this.radioButtonA.UseVisualStyleBackColor = true;
            // 
            // radioButtonB
            // 
            this.radioButtonB.AutoSize = true;
            this.radioButtonB.Location = new System.Drawing.Point(128, 19);
            this.radioButtonB.Name = "radioButtonB";
            this.radioButtonB.Size = new System.Drawing.Size(32, 17);
            this.radioButtonB.TabIndex = 6;
            this.radioButtonB.TabStop = true;
            this.radioButtonB.Text = "B";
            this.radioButtonB.UseVisualStyleBackColor = true;
            // 
            // radioButtonC
            // 
            this.radioButtonC.AutoSize = true;
            this.radioButtonC.Location = new System.Drawing.Point(229, 19);
            this.radioButtonC.Name = "radioButtonC";
            this.radioButtonC.Size = new System.Drawing.Size(32, 17);
            this.radioButtonC.TabIndex = 7;
            this.radioButtonC.TabStop = true;
            this.radioButtonC.Text = "C";
            this.radioButtonC.UseVisualStyleBackColor = true;
            // 
            // groupBoxRespostaCorrecta
            // 
            this.groupBoxRespostaCorrecta.Controls.Add(this.radioButtonA);
            this.groupBoxRespostaCorrecta.Controls.Add(this.radioButtonC);
            this.groupBoxRespostaCorrecta.Controls.Add(this.radioButtonB);
            this.groupBoxRespostaCorrecta.Location = new System.Drawing.Point(15, 222);
            this.groupBoxRespostaCorrecta.Name = "groupBoxRespostaCorrecta";
            this.groupBoxRespostaCorrecta.Size = new System.Drawing.Size(286, 50);
            this.groupBoxRespostaCorrecta.TabIndex = 0;
            this.groupBoxRespostaCorrecta.TabStop = false;
            this.groupBoxRespostaCorrecta.Text = "Resposta Correcta";
            // 
            // buttonDesar
            // 
            this.buttonDesar.Location = new System.Drawing.Point(15, 287);
            this.buttonDesar.Name = "buttonDesar";
            this.buttonDesar.Size = new System.Drawing.Size(286, 45);
            this.buttonDesar.TabIndex = 5;
            this.buttonDesar.Text = "Desar";
            this.buttonDesar.UseVisualStyleBackColor = true;
            // 
            // gestorPreguntes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 341);
            this.Controls.Add(this.buttonDesar);
            this.Controls.Add(this.groupBoxRespostaCorrecta);
            this.Controls.Add(this.textBoxRespostaC);
            this.Controls.Add(this.labelRespostaC);
            this.Controls.Add(this.textBoxRespostaB);
            this.Controls.Add(this.labelRespostaB);
            this.Controls.Add(this.textBoxRespostaA);
            this.Controls.Add(this.labelRespostaA);
            this.Controls.Add(this.textBoxPregunta);
            this.Controls.Add(this.labelPregunta);
            this.Name = "gestorPreguntes";
            this.Text = "Gestor de preguntes";
            this.groupBoxRespostaCorrecta.ResumeLayout(false);
            this.groupBoxRespostaCorrecta.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPregunta;
        private System.Windows.Forms.TextBox textBoxPregunta;
        private System.Windows.Forms.TextBox textBoxRespostaA;
        private System.Windows.Forms.Label labelRespostaA;
        private System.Windows.Forms.TextBox textBoxRespostaB;
        private System.Windows.Forms.Label labelRespostaB;
        private System.Windows.Forms.TextBox textBoxRespostaC;
        private System.Windows.Forms.Label labelRespostaC;
        private System.Windows.Forms.RadioButton radioButtonA;
        private System.Windows.Forms.RadioButton radioButtonB;
        private System.Windows.Forms.RadioButton radioButtonC;
        private System.Windows.Forms.GroupBox groupBoxRespostaCorrecta;
        private System.Windows.Forms.Button buttonDesar;
    }
}